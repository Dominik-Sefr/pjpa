import ttgen
import pytest
def test_correct_gen_value():
    t_time = ttgen.time_generator((0,0,0), (0,15,0), (0, 7, 0))
    result = False
    if next(t_time) == (0,0,0) and next(t_time) == (0,7,0) and next(t_time) == (0,14,0):
        result = True
    assert result

def test_gen_over_midnight():
    t_time = ttgen.time_generator((23,30,0), (0,30,0), (0, 30, 0))
    result = False
    if next(t_time) == (23,30,0) and next(t_time) == (0,0,0) and next(t_time) == (0,30,0):
        result = True
    assert result

def test_gen_stop_iteration():
    with pytest.raises(Exception):
        t_time = ttgen.time_generator((23,30,0), (0,30,0), (0, 30, 0))
        print(next(t_time))
        print(next(t_time))
        print(next(t_time))
        print(next(t_time))

def test_valid_random_time():
    result = False
    t_time = ttgen.random_time()
    if t_time[0] >= 0 and t_time[0] < 24 and t_time[1] >= 0 and t_time[1] < 60 and t_time[2] >= 0 and t_time[2] < 60:
        result = True
    assert result
