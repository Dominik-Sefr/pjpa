import random
def time_generator(start, end, step):
    start_sec = start[2]
    start_sec += 60*start[1]
    start_sec += 3600*start[0]
    end_sec = end[2]
    end_sec += 60*end[1]
    end_sec += 3600*end[0]
    midnight = False
    if start_sec > end_sec:
        midnight = True
    step_sec = step[2]
    step_sec += 60*step[1]
    step_sec += 3600*step[0]
    list = [start]
    while True:
        if (midnight == False) and (start_sec + step_sec) > end_sec:
            break
        if (midnight == True) and (start_sec) <= end_sec:
            midnight = False
        start_sec += step_sec
        if start_sec >= 86400:
            start_sec -= 86400
        list.append(toHours(start_sec))
        if start_sec == end_sec:
            break
    return iter(list)

def random_temp():
    """
    náhodná teplota
    """
    rnd_tmp = random.uniform(36,41.001)
    rnd_tmp = round(rnd_tmp, 2)
    return rnd_tmp

def random_time():
    """
    náhodný čas
    """
    rnd_sec = random.randrange(86400)
    return toHours(rnd_sec)

def toHours(seconds):
    "konverze sekund do formátováného času"
    hours = seconds // 3600
    seconds -= 3600*hours
    minutes = seconds // 60
    seconds -= 60*minutes
    return (hours,minutes,seconds)

def output(fname="sample.txt"):
    result = ""
    start = random_time()
    end = random_time()
    step = random_time()

    result += "\nstart = " + str(start[0])+":"+str(start[1])+":"+str(start[2]) + "\nend = " + str(end[0])+":"+str(end[1])+":"+str(end[2]) + "\nstep = " + str(step[0])+":"+str(step[1])+":"+str(step[2]) + "\n"
    for x in time_generator(start,end,step):
        result += "\n" + str(x[0])+":"+str(x[1])+":"+str(x[2]) + ", " + str(random_temp())

    f= open(fname,"w")
    f.write(result)
if __name__ == '__main__':
    output()
