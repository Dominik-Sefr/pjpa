"""
hledač
"""
import argparse
import errno
import os

def input_cmd():
    """
    parsování z console
    """
    parser = argparse.ArgumentParser(
        description='Najde řádky, které obsahují dané slova.'
    )
    parser.add_argument("-f", "--filename", metavar="", help="název souboru")
    parser.add_argument("-s", "--search", type=str, nargs="*", help="hledaná slova")
    task = parser.parse_args()

    if task.filename is None:
        parser.error("Vyberte prosím soubor pomocí -f 'název_souboru.txt'")
    if task.search == []:
        parser.error("By using '-s' you must also choose word(s) to search!")
    return task


def lines_find(lines, words):
    """
    hledání řádků
    """
    if words is None:
        for i in range(len(lines)):
            print(str(i+1)+":"+lines[i])
    else:
        for i in range(len(lines)):
            found = True
            for word in words:
                if word not in lines[i]:
                    found = False
                    break
            if found:
                print(str(i+1)+":"+lines[i])

def main():
    """
    hlavní kód
    """
    task = input_cmd()
    try:
        with open(task.filename, "r", encoding="utf-8") as file:
            data = file.readlines()
        lines_find(data, task.search)
    except:
        raise FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), task.filename)


if __name__ == '__main__':
    main()
