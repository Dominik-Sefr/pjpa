import sys
import pytest
import hledac

lines = ["prvni", "druhy", "treti", "ctvrty"]


def test_find_w_words_1(capfd):
    """
    celý soubor
    """
    hledac.lines_find(lines, None)
    out, __ = capfd.readouterr()
    assert out == "1:prvni\n2:druhy\n3:treti\n4:ctvrty\n"

def test_find_w_words_2(capfd):
    """
    celý řádek
    """
    words = "prvni"
    hledac.lines_find(lines, words)
    out, __ = capfd.readouterr()
    assert out == "1:prvni\n"

def test_find_w_words_3(capfd):
    """
    části řádku
    """
    words = ["r", "i"]
    hledac.lines_find(lines, words)
    out, __ = capfd.readouterr()
    print(out)
    assert out == "1:prvni\n3:treti\n"

def test_find_w_words_4(capfd):
    """
    velká/malá písmena
    """
    words = "PRV"
    hledac.lines_find(lines, words)
    out, __ = capfd.readouterr()
    assert out == ""

def test_input_parser_1():
    """
    chybějící soubor
    """
    sys.argv = ['hledac.py']
    with pytest.raises(SystemExit):
        hledac.input_cmd()

def test_input_parser_2():
    """
    jen jeden parametr
    """
    sys.argv = ['hledac.py', '--f', 'test.txt']
    file = "test.txt"
    search = None
    assert hledac.input_cmd().filename == file and hledac.input_cmd().search == search

def test_input_parser_3():
    """
    chybějící slova
    """
    sys.argv = ['hledac.py', '--f', 'test.txt', '--s']
    with pytest.raises(SystemExit):
        hledac.input_cmd()

def test_input_parser_4():
    """
    oba parametry, jedno slovo
    """
    sys.argv = ['hledac.py', '--f', 'test.txt', "--s", "word"]
    file = "test.txt"
    search = ["word"]
    assert hledac.input_cmd().filename == file and hledac.input_cmd().search == search

def test_input_parser_5():
    """
    oba parametry, více slov
    """
    sys.argv = ['hledac.py', '--f', 'test.txt', "--s", "word1", "word2"]
    file = "test.txt"
    search = ["word1", "word2"]
    assert hledac.input_cmd().filename == file and hledac.input_cmd().search == search

def test_main():
    """
    neexistující soubor
    """
    with pytest.raises(FileNotFoundError):
        sys.argv = ['hledac.py', '--f', 'test.txt']
        hledac.main()
