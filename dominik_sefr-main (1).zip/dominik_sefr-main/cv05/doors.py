# -*- coding: utf-8 -*-

"""
Úkol 5.
Napište program, který načte soubor large.txt a pro každé dveře vyhodnotí,
zda je možné je otevřít nebo ne. Tedy vyhodnotí, zda lze danou množinu uspořádat
požadovaným způsobem. Výstup z programu uložte do souboru vysledky.txt ve
formátu 1 výsledek =  1 řádek. Na řádek napište vždy počet slov v množině a True
nebo False, podle toho, zda řešení existuje nebo neexistuje.

Podrobnější zadání včetně příkladu je jako obvykle na elearning.tul.cz
"""
def decrypt():
    with open('large.txt') as f:
        lines = [line.rstrip('\n') for line in f]
        keys = [True] * int(lines[0])
        nums = [None] * int(lines[0])
        keyindex = 0
    for i in range(1, len(lines)):
        if lines[i].isnumeric():
            words = int(lines[i])
            nums[keyindex] = words
            for j in range(i+1, i+words+1):
                if j != i+1:
                    if lines[j-1][len(lines[j-1])-1] != lines[j][0]:
                        keys[keyindex] = False
            keyindex += 1

    for i in range(len(keys)):
        print(nums[i], " ", keys[i])

if __name__ == '__main__':
    decrypt()
