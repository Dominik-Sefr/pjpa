# -*- coding: utf-8 -*-
import re
import codecs
import json

def dict():
    with open('competitors.json', encoding="utf8") as json_file:
        data = json.loads(json_file.read())
    return data

CLEANR = re.compile('<.*?>')
pattern = r',\s\d*[)]'
pattern1 = r'[)]\s'
pattern2 = r'\s[(]'
pattern3 = r',\s'
pattern4 = r'(\d*:\d*:\d*)'
def slicer(my_str,sub):
    index=my_str.find(sub)
    if index !=-1 :
        return my_str[index:]
    else:
        raise Exception('Sub string not found!')

def cleanhtml(raw_html):
    cleantext = re.sub(CLEANR, '', raw_html)
    cleantext = slicer(cleantext, 'Relay')
    gender = cleantext.split("Men")
    women = re.split(pattern, gender[0])
    temptextwom = re.split(pattern1, women[0])
    women[0] = temptextwom[1]
    men = re.split(pattern, gender[1])
    temptextmen = re.split(pattern1, men[0])
    men[0] = temptextmen[1]
    for i in range(len(men)):
        temptext = re.split(pattern2, men[i])
        temptext1 = re.split(pattern4, temptext[0], 1)
        temptext[0] = temptext1[1]
        temptext[1] = temptext[1][:-1]

        men[i] = temptext
        tempnames = re.split(pattern3, men[i][1])
        for n in range(len(tempnames)):
            tempnames[n] = re.split(r'\s', tempnames[n], 1)

        men[i][1] = tempnames
        #print(men[i])
    regex = re.compile('[^a-zA-Z]')
    zatim = men[len(men)-1][1][2][1]
    zatim = regex.sub('', zatim)
    men[len(men)-1][1][2] = [men[len(men)-1][1][2][0], zatim]
    for i in range(len(women)):
        temptext = re.split(pattern2, women[i])
        temptext1 = re.split(pattern4, temptext[0], 1)
        temptext[0] = temptext1[1]
        temptext[1] = temptext[1][:-1]
        women[i] = temptext
        tempnames = re.split(pattern3, women[i][1])
        for n in range(len(tempnames)):
            tempnames[n] = re.split(r'\s', tempnames[n], 1)

        women[i][1] = tempnames
        #print(women[i])
    #del women[len(women)-1][1][2][]
    regex = re.compile('[^a-zA-Z]')
    zatim = women[len(women)-1][1][2][1]
    zatim = regex.sub('', zatim)
    women[len(women)-1][1][2] = [women[len(women)-1][1][2][0], zatim]
    print(women[len(women)-1])
    race = [men, women]
    return race
def test():
    f=codecs.open("result.html", 'r')
    return cleanhtml(f.read())

def final(data):
    dict = []
    i = 0
    j = 0
    for team in test()[0]:

        for names in team[1]:
            found = False
            for racer in data:
                if racer["lastname"] == names[1] and racer["firstname"] == names[0]:
                    id = racer["id"]
                    found = True
            if(found == False):
                nam = names[0] + " " + names[1]
                di = {
                "id": False,
                "result": i+1,
                "time": team[0],
                "no_match": nam
                }

            else:
                di = {
                "id": id,
                "result": i+1,
                "time": team[0]
                }
            dict.append(di)
        i = i + 1
    for team in test()[1]:

        for names in team[1]:
            found = False
            for racer in data:
                if racer["lastname"] == names[1] and racer["firstname"] == names[0]:
                    id = racer["id"]
                    found = True
            if(found == False):
                nam = names[0] + " " + names[1]
                di = {
                "id": False,
                "result": i+1,
                "time": team[0],
                "no_match": nam
                }

            else:
                di = {
                "id": id,
                "result": j+1,
                "time": team[0]
                }
            dict.append(di)
        j = j + 1
    return dict

def finalcompare(data):
    newlist = sorted(data, key=lambda d: d['id'])
    sorte = []
    errors = []
    for i in newlist:
        if(i["id"] != False):
            stre = str(i["id"]) + " " + str(i["result"])
            sorte.append(stre)
        else:
            stre = i["no_match"]
            errors.append(stre)
    str_sorte = ""
    str_errors = ""

    for i in sorte:
        str_sorte += "\n" + i
    for i in errors:
        str_errors += "\n" + i
    result = [str_sorte, str_errors]
    return result
def output_json(result_list, compare_text, errors_text):
    """
    Uloží list slovníků do souboru output.json tak jak je požadováno
    v zadání.
    """
    with open('output.json', 'w') as output:
        output.write(json.dumps(result_list, indent=4, sort_keys=True))
    with open("compare.txt", "w") as text_file:
        text_file.write(compare_text)
    with open("errors.txt", "w") as text_file1:
        text_file1.write(errors_text)



if __name__ == '__main__':
    data = dict()
    output_json(final(data),finalcompare(final(data))[0],finalcompare(final(data))[1])
    #final(data)
    pass
