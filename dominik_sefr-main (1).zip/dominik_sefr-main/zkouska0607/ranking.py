import re
import argparse
import errno
import os
def parsing(filename):
    """
    parse souboru do listu
    """
    try:
        with open(filename, encoding = "utf-8") as file:
            lines = file.readlines()
            lines = [line.rstrip() for line in lines]
    except:
        print("file not found")
        exit()
    list = []
    tooltip = lines[0].split(",")
    del lines[0]
    for line in lines:
        competitor = line.split(",")
        di = {
        tooltip[0]: competitor[0],
        tooltip[1]: competitor[1],
        tooltip[2]: competitor[2],
        tooltip[3]: int(competitor[3])
        }
        list.append(di)
    return list
"""
sort podle různých parametrů
"""
def sort_by_points(list):
    return sorted(list, key = lambda i: i["Points"], reverse = True)
def sort_by_team(list):
    return sorted(list, key = lambda i: i["Team"])
def sort_by_country(list):
    return sorted(list, key = lambda i: i["Country"])
def sort_by_country_points(list):
    return sorted(list, key = lambda i: (i["Country"], -i["Points"]))
def sort_by_country_points(list):
    return sorted(list, key = lambda i: (i["Country"], -i["Points"]))
def sort_by_country_team_points(list):
    return sorted(list, key = lambda i: (i["Country"], i["Team"], -i["Points"]))
def sort_by_team_points(list):
    return sorted(list, key = lambda i: (i["Team"], -i["Points"]))
def sort_by_country_team(list):
    return sorted(list, key = lambda i: (i["Country"], i["Team"]))


def input_parse():
    """
    console input
    """
    parser = argparse.ArgumentParser(
        description='Sorting competitors'
    )
    parser.add_argument("-i", "--input",type = str, required = True, help="file to sort")
    parser.add_argument("-n", "--numrows", type = int, metavar="number", help="number of lines to print")
    parser.add_argument("-p", "--points",action='store_true', help="sort by points")
    parser.add_argument("-t", "--teams",action='store_true', help="sort by teams")
    parser.add_argument("-c", "--countries",action='store_true', help="sort by countries")
    parser.add_argument("-cz", "--czech",action='store_true', help="finds best czech competitor")

    task = parser.parse_args()

    if task.input is None:
        parser.error("Missing input file!")

    return task

def main():
    """
    logika programu
    """
    task = input_parse()
    list_competitors = parsing(task.input)
    if(task.czech):
        sorted_list = sort_by_country_points(list_competitors)
        for element in sorted_list:
            if(element["Country"] == "cz"):
                printingline = list(element.values())
                print(', '.join(map(str,printingline)))
                break

    else:
        if (task.points is False and task.teams is False and task.countries is False):
            if(task.numrows is None or task.numrows < 1):
                for line in list_competitors:
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))
            else:
                iterator = task.numrows
                for line in list_competitors:
                    if(iterator == 0):
                        break
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))

        if (task.points is False and task.teams is False and task.countries is True):
            if(task.numrows is None or task.numrows < 1):
                for line in sort_by_country(list_competitors):
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))
            else:
                iterator = task.numrows
                for line in sort_by_country(list_competitors):
                    if(iterator == 0):
                        break
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))
                    iterator = iterator - 1

        if (task.points is True and task.teams is False and task.countries is False):
            if(task.numrows is None or task.numrows < 1):
                for line in sort_by_points(list_competitors):
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))
            else:
                iterator = task.numrows
                for line in sort_by_points(list_competitors):
                    if(iterator == 0):
                        break
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))
                    iterator = iterator - 1

        if (task.points is False and task.teams is True and task.countries is False):
            if(task.numrows is None or task.numrows < 1):
                for line in sort_by_team(list_competitors):
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))
            else:
                iterator = task.numrows
                for line in sort_by_team(list_competitors):
                    if(iterator == 0):
                        break
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))
                    iterator = iterator - 1

        if (task.points is False and task.teams is True and task.countries is True):
            if(task.numrows is None or task.numrows < 1):
                for line in sort_by_country_team(list_competitors):
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))
            else:
                iterator = task.numrows
                for line in sort_by_country_team(list_competitors):
                    if(iterator == 0):
                        break
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))
                    iterator = iterator - 1

        if (task.points is True and task.teams is False and task.countries is True):
            if(task.numrows is None or task.numrows < 1):
                for line in sort_by_country_points(list_competitors):
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))
            else:
                iterator = task.numrows
                for line in sort_by_country_points(list_competitors):
                    if(iterator == 0):
                        break
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))
                    iterator = iterator - 1

        if (task.points is True and task.teams is True and task.countries is False):
            if(task.numrows is None or task.numrows < 1):
                for line in sort_by_team_points(list_competitors):
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))
            else:
                iterator = task.numrows
                for line in sort_by_team_points(list_competitors):
                    if(iterator == 0):
                        break
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))
                    iterator = iterator - 1

        if (task.points is True and task.teams is True and task.countries is True):
            if(task.numrows is None or task.numrows < 1):
                for line in sort_by_country_team_points(list_competitors):
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))
            else:
                iterator = task.numrows
                for line in sort_by_country_team_points(list_competitors):
                    if(iterator == 0):
                        break
                    printingline = list(line.values())
                    print(', '.join(map(str,printingline)))
                    iterator = iterator - 1


if __name__ == '__main__':
    main()
