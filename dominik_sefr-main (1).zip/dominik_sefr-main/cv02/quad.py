#!/bin/env python
# -*- coding: utf-8 -*-
"""
PJP - cvičení číslo 2
"""
def angle(a,b,c):
    ab = (b[0]-a[0], b[1]-a[1])
    bc = (c[0]-b[0], c[1]-b[1])
    return (ab[0]*bc[1])-(ab[1]*bc[0])
def is_convex(a, b, c, d):
    if a == b or b == c or c == d or d == a or b == d or a == c:
        return False
    if angle(a,b,c) < 0 or angle(b,c,d) < 0 or angle(c,d,a) < 0 or angle(d,a,b) < 0:
        return False
    else:
        return True

if __name__ == '__main__':
    is_convex((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))
