def triangle(a, b, c):
    if (a**2)+(b**2)==(c**2) or (b**2)+(c**2) == (a**2) or (a**2)+(c**2) == (b**2):
        return True
    else:
        return False

if triangle(6,8,10):
    print("Yes")
else:
    print("No")
