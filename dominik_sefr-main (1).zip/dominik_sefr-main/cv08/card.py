"""
@TODO implementujte dle zadání cvičení 8
"""


class Card:
    """
    Třída pro reprezentaci hracích karet
    """
    def __init__(self, given_rank, given_suit):
        if(given_rank <= 14 and given_rank >= 2):
            self.rank = given_rank
        else:
            raise TypeError("Zadejte rank mezi 2 a 14 (včetně)")

        if(given_suit == "s" or given_suit == "k" or given_suit == "p" or given_suit == "t"):
            self.suit = given_suit
        else:
            raise TypeError("Zadejte správný suit ('s', 'k', 'p', 't')")
        pass


    def black_jack_rank(self):
        if(self.rank == 11):
            rank = 10
        elif(self.rank == 12):
            rank = 10
        elif(self.rank == 13):
            rank = 10
        elif(self.rank == 14):
            rank = 11
        elif(self.rank <= 10 and self.rank >= 2):
            rank = self.rank
        return rank

        pass
    def __eq__(self, other):
        return self.black_jack_rank() == other.black_jack_rank()
    def __gt__(self, other):
        return self.black_jack_rank() > other.black_jack_rank()
    def __ge__(self, other):
        return self.black_jack_rank() >= other.black_jack_rank()
    def __str__(karta):
        rank = karta.rank
        suit = karta.suit
        return sklonovani(rank, suit)
def sklonovani(rank, suit):
    if(rank == 11):
        rank = "spodek"
        if(suit == "s"):
            suit1 = "srdcový"
        elif(suit == "k"):
            suit1 = "kárový"
        elif(suit == "p"):
            suit1 = "pikový"
        else:
            suit1 = "trefový"
    elif(rank == 12):
        rank = "královna"
        if(suit == "s"):
            suit1 = "srdcová"
        elif(suit == "k"):
            suit1 = "kárová"
        elif(suit == "p"):
            suit1 = "piková"
        else:
            suit1 = "trefová"
    elif(rank == 13):
        rank = "král"
        if(suit == "s"):
            suit1 = "srdcový"
        elif(suit == "k"):
            suit1 = "kárový"
        elif(suit == "p"):
            suit1 = "pikový"
        else:
            suit1 = "trefový"
    elif(rank == 14):
        rank = "eso"
        if(suit == "s"):
            suit1 = "srdcové"
        elif(suit == "k"):
            suit1 = "kárové"
        elif(suit == "p"):
            suit1 = "pikové"
        else:
            suit1 = "trefové"
    else:
        if(rank == 2):
            rank = "dvojka"
        elif(rank == 3):
            rank = "trojka"
        elif(rank == 4):
            rank = "čtyřka"
        elif(rank == 5):
            rank = "pětka"
        elif(rank == 6):
            rank = "šestka"
        elif(rank == 7):
            rank = "sedma"
        elif(rank == 8):
            rank = "osma"
        elif(rank == 9):
            rank = "devítka"
        elif(rank == 10):
            rank = "desítka"

        if(suit == "s"):
            suit1 = "srdcová"
        elif(suit == "k"):
            suit1 = "kárová"
        elif(suit == "p"):
            suit1 = "piková"
        else:
            suit1 = "trefová"

    strin = suit1 + " " + rank
    return strin



if __name__ == '__main__':
    pass
