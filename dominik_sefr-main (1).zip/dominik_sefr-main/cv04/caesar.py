"""
Vytvorte funkce encrypt a decrypt pro Caesarovu sifru.
Kompletni zadani v elearningu.
"""


def encrypt(word, offset):
    letters = list(word)
    cipher  = ''

    ceasar_lower = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    ceasar_upper = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']

    for letter in letters:
        if letter.isupper():
            if letter in ceasar_upper:
                oldindex = ceasar_upper.index(letter)
                newindex = (oldindex + offset) % len(ceasar_upper)
                newletter = ceasar_upper[newindex]
            else:
                newletter = letter
        else:
            if letter in ceasar_lower:
                oldindex = ceasar_lower.index(letter)
                newindex = (oldindex + offset) % len(ceasar_lower)
                newletter = ceasar_lower[newindex]
            else:
                newletter = letter
        cipher += newletter
    return cipher

def decrypt(word, offset):
    letters = list(word)
    cipher  = ''

    ceasar_lower = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    ceasar_upper = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']

    for letter in letters:
        if letter.isupper():
            if letter in ceasar_upper:
                oldindex = ceasar_upper.index(letter)
                newindex = (oldindex - offset) % len(ceasar_upper)
                newletter = ceasar_upper[newindex]
            else:
                newletter = letter
        else:
            if letter in ceasar_lower:
                oldindex = ceasar_lower.index(letter)
                newindex = (oldindex - offset) % len(ceasar_lower)
                newletter = ceasar_lower[newindex]
            else:
                newletter = letter
        cipher += newletter
    return cipher

#print(encrypt("ahoj AHOJ",1))
#print(decrypt(encrypt("ahoj AHOJ",1),1))
